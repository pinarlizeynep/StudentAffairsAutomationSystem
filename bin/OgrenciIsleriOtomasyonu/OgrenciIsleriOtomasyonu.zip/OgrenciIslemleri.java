package OgrenciIsleriOtomasyonu;

interface OgrenciIslemleri {
	void dersSec(String dersAdi);
}