package OgrenciIsleriOtomasyonu;

interface VeriIslemleri {
    void sifreDegistir(String yeniSifre);
    void idDegistir(String yeniId);
}