package OgrenciIsleriOtomasyonu;

interface OgretmenIslemleri {
    void dersEkle();
    void notGir(String ogrenciId, String dersKodu, int not);
}